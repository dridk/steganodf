from .algorithm import Algorithm


class PermutationAlgorithm(Algorithm):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

