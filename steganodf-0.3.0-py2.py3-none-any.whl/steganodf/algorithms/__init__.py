
from .bitpool import BitPool

ALGORITHMS = {
    "bitpool" : BitPool
}


